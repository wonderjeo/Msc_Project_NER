#pip install -U spacy
#python -m spacy download en_core_web_sm

import spacy
from pathlib import Path
nlp = spacy.load("en_core_web_lg")

file_name ="lab.txt"
line_counts =0
word_counts =0
character_counts =0
aList = []

output=open(r'lab_spacy_lg_pred.txt','w',encoding="utf8") 

with Path(file_name).open('r',encoding="utf8") as f:
    for line in f:  
        output.write(line)
        output.write('\n')
        doc = nlp(line)
        for ent in doc.ents:
            output.write(ent.label_)
            output.write(' -> ')
            output.write(ent.text)
            output.write('\n')
        output.write('#################\n')



