import sys,os

"""
python实现任一个英文的纯文本文件，统计其中的单词出现的个数、行数、字符数
"""
file_name ="lab_words.txt"
line_counts =0
word_counts =0
character_counts =0
aList = []

with Path(file_name).open('r',encoding="utf8") as f:
    for line in f:
        word_counts =0
        words = line.split()#split()用于分割，分隔符可以自己制定
        line_counts +=1
        word_counts +=len(words)
        character_counts +=len(line)
        aList.append(word_counts)
print ("#######################################")

file_name ="lab_tags.txt"
line_counts =0
word_counts =0
character_counts =0
bList = []

with Path(file_name).open('r',encoding="utf8") as f:
    for line in f:
        word_counts =0
        words = line.split()#split()用于分割，分隔符可以自己制定
        line_counts +=1
        word_counts +=len(words)
        character_counts +=len(line)
        bList.append(word_counts)
print ("#######################################")
#print (bList)
print ("#######################################")
       
       
v = list(map(lambda x: x[0]-x[1], zip(aList, bList)))
length = len(v)
i = 0
while(i<length):
    if(v[i]!=0):
        print(i+1)
    i = i+1
#print (v)